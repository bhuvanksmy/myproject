/**
 * 
 */
package com.Portfolio_Project.ProductService.Controller;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

/**
 * 
 */
public class Product_ControllerTest {

	/**
	 * @throws java.lang.Exception
	 */
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
	}

	/**
	 * @throws java.lang.Exception
	 */
	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}

	/**
	 * @throws java.lang.Exception
	 */
	@Before
	public void setUp() throws Exception {
	}

	/**
	 * @throws java.lang.Exception
	 */
	@After
	public void tearDown() throws Exception {
	}

	/**
	 * Test method for {@link com.Portfolio_Project.ProductService.Controller.Product_Controller#createProduct(com.Portfolio_Project.ProductService.dto.ProductRequest)}.
	 */
	@Test
	public void testCreateProduct() {
		throw new RuntimeException("not yet implemented");
	}

	/**
	 * Test method for {@link com.Portfolio_Project.ProductService.Controller.Product_Controller#getAllProducts()}.
	 */
	@Test
	public void testGetAllProducts() {
		throw new RuntimeException("not yet implemented");
	}

}
