package com.Portfolio_Project.ProductService.Repository;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.Portfolio_Project.ProductService.model.Product;

public interface Product_Repository extends MongoRepository<Product, String>{

}
