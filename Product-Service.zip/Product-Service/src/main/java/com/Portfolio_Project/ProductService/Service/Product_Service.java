package com.Portfolio_Project.ProductService.Service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.Portfolio_Project.ProductService.Repository.Product_Repository;
import com.Portfolio_Project.ProductService.dto.ProductRequest;
import com.Portfolio_Project.ProductService.dto.ProductResponse;
import com.Portfolio_Project.ProductService.model.Product;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Service
@RequiredArgsConstructor
@Slf4j
public class Product_Service {
	private final Product_Repository productRepository;
	public void createProduct(ProductRequest productRequest) {
		Product product = Product.builder()
				.name(productRequest.getName())
				.description(productRequest.getDescription())
				.price(productRequest.getPrice())
				.build();
		productRepository.save(product);
		log.info("Product {} is saved", product.getId());
	}
	public List<ProductResponse> getAllProducts() {
		// TODO Auto-generated method stub
		List<Product> products = productRepository.findAll();
		 return products.stream().map(this :: mapToProductResponse).toList();
		
	}
	private ProductResponse mapToProductResponse(Product product) {
		// TODO Auto-generated method stub
		return ProductResponse.builder()
			.id(product.getId())
			.name(product.getName())
			.description(product.getDescription())
			.price(product.getPrice())
			.build();
	}
}
